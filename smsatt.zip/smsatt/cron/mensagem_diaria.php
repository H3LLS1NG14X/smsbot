<?php

include __DIR__.'/../includes/includes.php';

$tlg = new Telegram (6634589388:AAHRgehb1qaQzDJJ03f3Ugc9eIJpkOY1nLw);

$tlg->sendMessage ([
'GRUPO_ID' => '@H3LLS1NGCOMPANY',
'text' => "<b>🤓 RECEBA SMS COM NÚMEROS NOVOS PARA CRIAR CONTAS</b>

- Telegram
- Whatsapp
- 99app
- Banqi
- Uber
- E muitos outros...

💬 Receba os códigos no nosso bot
@itachisms_bot

🌐 Canal de Referências
@itachisms
📍 Nosso grupo
@itachisms2

*Preço e serviço incomparável com os existentes.
*Mais de 4 mil números disponíveis",
'parse_mode' => 'html'
]);