<?php

include __DIR__.'/../includes/includes.php';

$tlg = new Telegram ('6634589388:AAHRgehb1qaQzDJJ03f3Ugc9eIJpkOY1nLw');

print_r ($tlg->sendDocument ([
	'chat_id' => @jhonni12,
	'caption' => "Backup\n@jhonni12\n".date ('d/m/Y H:i:s'),
	'document' => curl_file_create (__DIR__.'/../recebersmsbot.db')
]));