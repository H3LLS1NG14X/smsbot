<?php

$tlg->sendMessage ([
	'chat_id' => $tlg->ChatID (),
	'text' => "<b>📜 · @JHONNI12 \n\n ▫️ · SUPORTE: @H3LLS1NG14X</b>",
	'parse_mode' => 'html'
]);