﻿<?php

$tlg->sendMessage ([
	'chat_id' => $tlg->ChatID (),
	'text' => "🎈<b>Como receber sms pelo bot?</b>\nUse o comando /servicos e veja os serviços disponíveis para receber sms.\n\n🎈<b>Como colocar saldo na minha conta?</b>\nUse o comando /recarregar escolha o valor, após o pagamento o saldo é adicionado automaticamente na sua conta.\n\n🎈 <b>Posso ficar com o número após o uso?</b>\nNão, os números são descartaveis/temporarios, após o uso eles são substituidos por novos, servindo somente para confirmação ou criação de cadastros.\n\n🎈<b>Como resgatar meu saldo comprado?</b>\nO saldo é adicionado automaticamente na sua conta, caso isso não aconteça entre em contato com @H3LLS1NG14X\n\n🎈<b>Não tem números disponíveis!</b>\nUse o comando /alertas, você será notificado quando novos números estiverem disponíveis para o serviço escolhido.\n\n<b>Termos de uso:</b>\n<em>Em caso de quaisquer tipo de abusos no uso do bot você pode ser penalizado com bloqueio ou redução no seu saldo atual, esses termos entram em vigor apartir do momento em que você iniciou o bot.</em>\n\n<em><a href=\"https://t.me/H3LLS1NGCOMPANY\">Nosso canal de referencias</a></em> 💬",
	'parse_mode' => 'html'
]);
