﻿<?php
$saldo = (string)number_format ($user ['saldo'], 2);
$tlg->sendMessage ([
	'chat_id' => $tlg->ChatID (),
	'text' => "😀 <b>Olá ".htmlentities ($tlg->FirstName ())."</b>, Seja Bem vindo a Store de SMS Ficamos Muito felizes de recebelo!!!\n\nSeu saldo<code> R\${$saldo}</code>\nSeu ID: <code>{$tlg->UserID ()}</code>\nVeja nossos termos /termos\n\nNão curtiu esse menu? digite /start1 e veja o outro menu!!\n<b><em><a href=\"https://t.me/suleiman171\">👨🏾‍💻 · SUPORTE</a></em></b>",
	'parse_mode' => 'html',
	'disable_web_page_preview' => true,
	'reply_markup' => $tlg->buildInlineKeyboard ([
			[$tlg->buildInlineKeyBoardButton ("📲Depositar", null, "/recarregar"),$tlg->buildInlineKeyBoardButton ("📲Pix manual", null, "/recarregar")],[$tlg->buildInlineKeyBoardButton ("💰Saldo", null, "/saldo"),$tlg->buildInlineKeyBoardButton ("🔥Serviços", null, "/servicos"),$tlg->buildInlineKeyBoardButton ("👥 Informações", null, "/sobre"),$tlg->buildInlineKeyBoardButton ("🚩 Países", null, "/paises")],[$tlg->buildInlineKeyBoardButton ("♦️Dica", null, "/dica")],[$tlg->buildInlineKeyBoardButton ("👥Afiliado👥", null, "/afiliado")]
		])
]);

// afiliados
if (isset ($complemento) && is_numeric ($complemento) && STATUS_AFILIADO){

	$ref = $tlg->getUsuarioTlg ($complemento);

	// se usuario existir e não tiver entrado no bot por indicação de alguem e tambem não pode ser ele mesmo
	if (isset ($ref ['id']) && $bd_tlg->checkReferencia ($tlg->UserID ()) == false && $complemento != $tlg->UserID ()){

		// salva usuario atual como referencia do dono do link
		$bd_tlg->setReferencia ($complemento, $tlg->UserID ());

	}

}