<?php

$tlg->sendMessage ([
	'chat_id' => $tlg->ChatID (),
	'text' => "<b>No momento os bots ofcs sao: @NumerosVirtuaisCompany_bot\n\nE o meu substituto: @JHONNI12",
	'parse_mode' => 'html'
]);