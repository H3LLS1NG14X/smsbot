<?php

$tlg->sendMessage ([
	'chat_id' => $tlg->ChatID (),
	'text' => "<b>📜 · @H3LLS1NG14X \n\n ▫️ · SUPORTE: @H3LLS1NG14X</b>",
	'parse_mode' => 'html'
]);