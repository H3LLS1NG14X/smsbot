<?php
if (!$complemento){
	$tlg->sendMessage ([
		'chat_id' => $tlg->ChatID (),
		'text' => "Digite o comando /cpf NUMERO\nExemplo: <b>/cpf 12345567890</b> ",
		'parse_mode' => 'html'
	]);
	}else {
			$url = "https://dualityapi.xyz/apis/teste/Consultas%20Privadas/JSON/placa.php?consulta=".$complemento;
			$obj = json_decode(file_get_contents($url), true);
			$id = (string)($obj['id']);
			$tlg->sendMessage ([
				'chat_id' => $tlg->ChatID (),
				'text' => "{$id}",
				'parse_mode' => 'html']);

}