<?php

$tlg->sendMessage ([
	'chat_id' => $tlg->ChatID (),
	'text' => "<b>Algumas recomendações para um bom uso do bot:

 Quando forem usar mais de um número para o mesmo site ou app limpem o cache ou cookie do app ou site, entre por guia anônima ou use VPN pois alguns serviços usam mecanismos para impedir abuso no envio de códigos para vários números de um único usuário.

 Evite o cancelamento de vários números pois você pode ser penalizado com desconto de saldo e block, siga a dica acima para ter um bom proveito do número.

 Qualquer dúvida fale com @suleiman171
</b>",
	'parse_mode' => 'html'
]);